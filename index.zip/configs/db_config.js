module.exports = {
  host: "localhost",
  user: "root",
  password: "",
  port: 8111,
  database: "data_m",
  dialect: "mysql",
};
